##########
# Win10 David Cleanup script
# Author David
# Version: 1 10/12/21
##########

# do me first!
#Set-ExecutionPolicy Unrestricted

#useful commands
#Get-WindowsOptionalFeature -Online
#Get-AppxPackage *??*

#packages

Write-Host "Uninstalling default Microsoft packages..."
Get-AppxPackage "CortanaApp.View.App" | Remove-AppxPackage
Get-AppxPackage "Microsoft.BingWeather" | Remove-AppxPackage
Get-AppxPackage "Microsoft.GetHelp" | Remove-AppxPackage
Get-AppxPackage "Microsoft.Getstarted" | Remove-AppxPackage
Get-AppxPackage "Microsoft.Microsoft3DViewer" | Remove-AppxPackage
Get-AppxPackage "Microsoft.MicrosoftOfficeHub" | Remove-AppxPackage
Get-AppxPackage "Microsoft.MicrosoftSolitaireCollection" | Remove-AppxPackage
Get-AppxPackage "Microsoft.MicrosoftStickyNotes" | Remove-AppxPackage
Get-AppxPackage "Microsoft.MixedReality.Portal" | Remove-AppxPackage
#Get-AppxPackage "Microsoft.MSPaint" | Remove-AppxPackage
Get-AppxPackage "Microsoft.Office.OneNote" | Remove-AppxPackage
Get-AppxPackage "Microsoft.People" | Remove-AppxPackage
Get-AppxPackage "Microsoft.ScreenSketch" | Remove-AppxPackage
Get-AppxPackage "Microsoft.SkypeApp" | Remove-AppxPackage
Get-AppxPackage "Microsoft.WindowsAlarms" | Remove-AppxPackage
#Get-AppxPackage "Microsoft.WindowsCalculator" | Remove-AppxPackage
Get-AppxPackage "microsoft.windowscommunicationsapps" | Remove-AppxPackage
Get-AppxPackage "Microsoft.WindowsFeedbackHub" | Remove-AppxPackage
Get-AppxPackage "Microsoft.WindowsMaps" | Remove-AppxPackage
Get-AppxPackage "Microsoft.Xbox.TCUI" | Remove-AppxPackage
Get-AppxPackage "Microsoft.XboxApp" | Remove-AppxPackage
Get-AppxPackage "Microsoft.XboxGameOverlay" | Remove-AppxPackage
Get-AppxPackage "Microsoft.XboxGamingOverlay" | Remove-AppxPackage
Get-AppxPackage "Microsoft.XboxIdentityProvider" | Remove-AppxPackage
Get-AppxPackage "Microsoft.XboxSpeechToTextOverlay" | Remove-AppxPackage
Get-AppxPackage "Microsoft.ZuneMusic" | Remove-AppxPackage
Get-AppxPackage "Microsoft.ZuneVideo" | Remove-AppxPackage
Get-AppxPackage "Microsoft.ConnectivityStore" | Remove-AppxPackage
Get-AppxPackage "Microsoft.Messaging" | Remove-AppxPackage
Get-AppxPackage "Microsoft.AppConnector" | Remove-AppxPackage

#remove cortana
Get-AppxPackage -allusers Microsoft.549981C3F5F10 | Remove-AppxPackage

#remove system apps
Write-Host "Uninstalling default sysetm packages..."
#Get-AppxPackage Microsoft.MicrosoftEdge_8wekyb3d8bbwe | Remove-AppxPackage
#Get-AppxPackage Microsoft.MicrosoftEdgeDevToolsClient_8wekyb3d8bbwe | Remove-AppxPackage
Get-AppxPackage Microsoft.Windows.AddSuggestedFoldersToLibarayDialog_8wekyb3d8bbwe | Remove-AppxPackage
Get-AppxPackage Microsoft.Windows.FileExplorer_8wekyb3d8bbwe | Remove-AppxPackage
Get-AppxPackage Microsoft.Windows.PeopleExperienceHost_8wekyb3d8bbwe | Remove-AppxPackage
Get-AppxPackage Microsoft.XboxGameCallableUI_8wekyb3d8bbwe | Remove-AppxPackage
Get-AppxPackage Microsoft.Windows.NarratorQuickStart_8wekyb3d8bbwe | Remove-AppxPackage

#Other Junk
Write-Host "Uninstalling default Microsoft junk applications..."
Get-AppxPackage "Microsoft.3DBuilder" | Remove-AppxPackage
Get-AppxPackage "Microsoft.BingFinance" | Remove-AppxPackage
Get-AppxPackage "Microsoft.BingNews" | Remove-AppxPackage
Get-AppxPackage "Microsoft.BingSports" | Remove-AppxPackage
Get-AppxPackage "9E2F88E3.Twitter" | Remove-AppxPackage
Get-AppxPackage "king.com.CandyCrushSodaSaga" | Remove-AppxPackage
Get-AppxPackage "Microsoft.Office.Sway" | Remove-AppxPackage
Get-AppxPackage "Microsoft.WindowsAlarms" | Remove-AppxPackage
Get-AppxPackage "Microsoft.WindowsPhone" | Remove-AppxPackage
Get-AppxPackage "Microsoft.CommsPhone" | Remove-AppxPackage
Get-AppxPackage "Microsoft.MSPaint" | Remove-AppxPackage
Get-AppxPackage *Microsoft.YourPhone* -AllUsers | Remove-AppxPackage
Get-AppxPackage "Microsoft.Wallet" | Remove-AppxPackage

#Capabilties
Write-Host "Uninstalling default Microsoft capabilties..."
Disable-windowsoptionalfeature -online -featureName WindowsMediaPlayer
Disable-windowsoptionalfeature -online -featureName Printing-XPSServices-Features
Disable-windowsoptionalfeature -online -featureName Internet-Explorer-Optional-amd64




##########
# Restart
##########
Write-Host
Write-Host "Press any key to restart your system..." -ForegroundColor Black -BackgroundColor White
$key = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
Write-Host "Restarting..."
Restart-Computer


